# pylogalert

Logging JSON enxuto com **contexto async-safe**, **redaction de PII**, **sampling** e **alertas EMERGENCY** (Slack, e-mail), pronto para produção.

## Instalação
```bash
pip install pylogalert
